<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('welcome');
    return redirect('sample');
});
// Route::get('/sample/{id}', function ($id) {
Route::get('/sample', function () {
	// echo $id;
    return view('sample');
});
// Route::view('here','sample');
// Route::view('sample','sample');
// Route::view('/','sample');